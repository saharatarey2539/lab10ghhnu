package rmuti.test;

public class App {
	public static void main(String[] args) {
		NumberUtil number = new NumberUtil();
		int[] arr = { 2,3,4,5,6 };
		System.out.println(number.sumArray(arr));
	}
}
